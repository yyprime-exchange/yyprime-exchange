

export class ZetaMarketsClient {
  cluster: string;

  constructor(cluster: string) {
    this.cluster = cluster;
  }

}
