

export class PsyAmericanClient {
  cluster: string;

  constructor(cluster: string) {
    this.cluster = cluster;
  }

}
