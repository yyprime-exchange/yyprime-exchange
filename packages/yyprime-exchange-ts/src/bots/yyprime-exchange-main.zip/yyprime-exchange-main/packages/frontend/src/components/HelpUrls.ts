export const helpUrls = {
  customerSupport: 'https://t.me/ProjectSerum',
  contactEmail: 'mailto:contact@projectserum.com',
  discord: 'https://discord.gg/EDvudv6',
  telegram: 'https://t.me/ProjectSerum',
  twitter: 'https://t.me/ProjectSerum',
  github: 'https://github.com/project-serum',
  yyprime: 'https://projectserum.com/',
  solanaBeach: 'https://solanabeach.io',
}
