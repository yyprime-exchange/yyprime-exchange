declare module 'buffer-layout' {
  const bl: any
  export = bl
}

declare module 'jazzicon' {
  const jazzicon: any
  export = jazzicon
}
