export const Background = ({ children }) => {
  return <div className="bg__yyprime">{children}</div>
}

export default Background
